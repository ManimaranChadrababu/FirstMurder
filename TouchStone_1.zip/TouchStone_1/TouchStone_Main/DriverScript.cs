﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TouchStone_1.TouchStone_Main
{
    class DriverScript
    {

        public static IWebDriver driver { get; set; }

        public DriverScript(){
            driver = new ChromeDriver();
            }

    }
}
