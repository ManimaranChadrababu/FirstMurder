﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TouchStone_1.TouchStone_Main;
using TouchStone_1.Utils;

namespace TouchStone_1
{
    class SelfStart
    {
        static void Main(string[] args)
        {
            // DriverScript ds = new DriverScript();
            Logger.Instance.Initialize(@"D:\log.log");
            Logger.Instance.InfoLog("Logger intialized");
            ExcelUtil ex = new ExcelUtil();
            ex.ReadExcel();
        }
    }
}
