﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TouchStone_1.TouchStone_Main;

namespace TouchStone_1.Elements
{
    class TextBox : DriverScript
    {
        public void EnterText(IWebElement element,String value)
        {
            element.Clear();
            element.SendKeys(value);
        }

        public void EnterText(By by,String value)
        {
            var ele = driver.FindElement(by);
            ele.Clear();
            ele.SendKeys(value);
        }
    }
}
